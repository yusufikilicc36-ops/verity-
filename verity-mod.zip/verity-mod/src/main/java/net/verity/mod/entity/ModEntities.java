package net.verity.mod.entity;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.verity.mod.VerityMod;

public final class ModEntities {

    public static final EntityType<VerityEntity> VERITY = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(VerityMod.MOD_ID, "verity"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, VerityEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.9f))
                    .trackRangeChunks(10)
                    .build()
    );

    private ModEntities() {
    }

    public static void register() {
        FabricDefaultAttributeRegistry.register(VERITY, VerityEntity.createVerityAttributes());
    }
}
