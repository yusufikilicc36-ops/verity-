package net.verity.mod.client;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.verity.mod.VerityMod;
import net.verity.mod.entity.VerityEntity;

public class VerityEntityRenderer extends MobEntityRenderer<VerityEntity, VerityEntityModel> {

    private static final Identifier FRIENDLY_TEXTURE =
            new Identifier(VerityMod.MOD_ID, "textures/entity/verity_friendly.png");
    private static final Identifier TRANSFORMED_TEXTURE =
            new Identifier(VerityMod.MOD_ID, "textures/entity/verity_transformed.png");

    public VerityEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new VerityEntityModel(context.getPart(VerityModClient.VERITY_MODEL_LAYER)), 0.4f);
    }

    @Override
    public Identifier getTexture(VerityEntity entity) {
        return entity.isTransformed() ? TRANSFORMED_TEXTURE : FRIENDLY_TEXTURE;
    }

    @Override
    protected void scale(VerityEntity entity, MatrixStack matrices, float amount) {
        float scale = entity.isTransformed() ? 2.6f : 1.0f;
        matrices.scale(scale, scale, scale);
    }
}
