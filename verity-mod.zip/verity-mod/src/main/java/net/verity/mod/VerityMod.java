package net.verity.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.verity.mod.entity.ModEntities;
import net.verity.mod.item.ModItems;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VerityMod implements ModInitializer {

    public static final String MOD_ID = "veritymod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Verity is watching...");

        ModEntities.register();
        ModItems.register();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                VerityCommand.register(dispatcher));
    }
}
