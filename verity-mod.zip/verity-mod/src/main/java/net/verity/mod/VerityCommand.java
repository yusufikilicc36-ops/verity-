package net.verity.mod;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.verity.mod.entity.VerityEntity;

import java.util.List;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class VerityCommand {

    private VerityCommand() {
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("talktoverity")
                .then(argument("message", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            ServerCommandSource source = ctx.getSource();
                            PlayerEntity player = source.getPlayer();
                            if (player == null) return 0;

                            String message = StringArgumentType.getString(ctx, "message");

                            List<VerityEntity> nearby = player.getWorld().getEntitiesByClass(
                                    VerityEntity.class, player.getBoundingBox().expand(32.0), v -> true);

                            if (nearby.isEmpty()) {
                                player.sendMessage(Text.literal("There's no Verity nearby to hear you.")
                                        .formatted(Formatting.GRAY), false);
                                return 0;
                            }

                            VerityEntity verity = nearby.get(0);
                            verity.respondTo(player, message);
                            return 1;
                        })));
    }
}
