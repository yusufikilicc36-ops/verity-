package net.verity.mod.item;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.verity.mod.VerityMod;
import net.verity.mod.entity.ModEntities;

public final class ModItems {

    public static final Item VERITY_SPAWN_EGG = new SpawnEggItem(
            ModEntities.VERITY, 0xF5E642, 0x2B2B2B,
            new Item.Settings()
    );

    private ModItems() {
    }

    public static void register() {
        Registry.register(Registries.ITEM, new Identifier(VerityMod.MOD_ID, "verity_spawn_egg"), VERITY_SPAWN_EGG);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> entries.add(VERITY_SPAWN_EGG));
    }
}
