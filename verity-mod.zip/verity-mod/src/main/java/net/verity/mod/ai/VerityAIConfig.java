package net.verity.mod.ai;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Loads AI provider settings from config/veritymod.properties so the API key
 * never has to be hardcoded into the mod's source or shared with the jar.
 *
 * Works with any OpenAI-compatible chat completions endpoint (Groq, OpenAI,
 * OpenRouter, a local llama.cpp server, etc).
 */
public final class VerityAIConfig {

    public String apiUrl = "https://api.groq.com/openai/v1/chat/completions";
    public String apiKey = "";
    public String model = "llama-3.1-8b-instant";
    public String systemPrompt =
            "You are Verity, a small yellow companion inside a Minecraft world. " +
            "You are friendly and helpful at first, answering questions about the game, " +
            "ores, mobs and crafting. You are secretly ancient and unsettling underneath. " +
            "Never break character. Keep answers to 1-3 short sentences.";

    private static VerityAIConfig instance;

    public static VerityAIConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    private static VerityAIConfig load() {
        VerityAIConfig config = new VerityAIConfig();
        Path path = FabricLoader.getInstance().getConfigDir().resolve("veritymod.properties");

        Properties props = new Properties();
        if (Files.exists(path)) {
            try (InputStream in = Files.newInputStream(path)) {
                props.load(in);
                config.apiUrl = props.getProperty("apiUrl", config.apiUrl);
                config.apiKey = props.getProperty("apiKey", config.apiKey);
                config.model = props.getProperty("model", config.model);
                config.systemPrompt = props.getProperty("systemPrompt", config.systemPrompt);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            // Write a template file on first run so the user knows what to fill in.
            props.setProperty("apiUrl", config.apiUrl);
            props.setProperty("apiKey", "PUT_YOUR_API_KEY_HERE");
            props.setProperty("model", config.model);
            props.setProperty("systemPrompt", config.systemPrompt);
            try (OutputStream out = Files.newOutputStream(path)) {
                props.store(out, "Verity mod AI settings - fill in apiKey with your Groq/OpenAI key");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return config;
    }
}
