package net.verity.mod.entity.goal;

import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.verity.mod.entity.VerityEntity;
import net.verity.mod.entity.VerityState;

import java.util.EnumSet;
import java.util.List;

/**
 * Periodically whispers a line into chat to nearby players. Which lines are
 * eligible depends on the current state and how many "trust days" have passed,
 * mirroring the original's countdown ("something is coming in three days").
 */
public class VerityWhisperGoal extends Goal {

    private final VerityEntity verity;
    private int cooldown;

    public VerityWhisperGoal(VerityEntity verity) {
        this.verity = verity;
        this.setControls(EnumSet.noneOf(Control.class));
        this.cooldown = randomInterval();
    }

    @Override
    public boolean canStart() {
        return verity.getState() != VerityState.FRIENDLY;
    }

    @Override
    public boolean shouldContinue() {
        return canStart();
    }

    @Override
    public void tick() {
        cooldown--;
        if (cooldown > 0) return;
        cooldown = randomInterval();
        whisperToNearbyPlayers();
    }

    private int randomInterval() {
        // Roughly every 20-50 seconds
        return 400 + verity.getRandom().nextInt(600);
    }

    private void whisperToNearbyPlayers() {
        List<PlayerEntity> nearby = verity.getWorld().getEntitiesByClass(
                PlayerEntity.class,
                verity.getBoundingBox().expand(24.0),
                p -> true
        );
        if (nearby.isEmpty()) return;

        String key = pickLineKey();
        Text message = Text.translatable(key).formatted(net.minecraft.util.Formatting.YELLOW, net.minecraft.util.Formatting.ITALIC);
        for (PlayerEntity player : nearby) {
            player.sendMessage(message, false);
        }
    }

    private String pickLineKey() {
        int daysLeft = verity.getDaysUntilTransformation();

        if (verity.getState() == VerityState.TRANSFORMED) {
            return "veritymod.whisper.4"; // "You shouldn't have said that."
        }

        // Countdown-specific lines take priority as the day gets closer.
        if (daysLeft <= 1) {
            return "veritymod.whisper.9";
        } else if (daysLeft == 2) {
            return "veritymod.whisper.8";
        } else if (daysLeft == 3) {
            return "veritymod.whisper.3";
        }

        String[] generic = {
                "veritymod.whisper.1",
                "veritymod.whisper.2",
                "veritymod.whisper.5",
                "veritymod.whisper.6",
                "veritymod.whisper.7"
        };
        return generic[verity.getRandom().nextInt(generic.length)];
    }
}
