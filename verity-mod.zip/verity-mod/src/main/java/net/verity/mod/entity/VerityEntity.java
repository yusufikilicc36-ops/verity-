package net.verity.mod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.verity.mod.VerityMod;
import net.verity.mod.ai.VerityChatHandler;
import net.verity.mod.entity.goal.VerityFollowGoal;
import net.verity.mod.entity.goal.VerityStalkGoal;
import net.verity.mod.entity.goal.VerityWhisperGoal;

import java.util.List;

public class VerityEntity extends PathAwareEntity {

    private static final TrackedData<Integer> STATE =
            DataTracker.registerData(VerityEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> TICKS_ALIVE =
            DataTracker.registerData(VerityEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Boolean> RULE_BROKEN =
            DataTracker.registerData(VerityEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    /** Minecraft days before Verity transforms, mirroring the original's "3 days" countdown. */
    private static final int TRANSFORMATION_DAY_COUNT = 3;
    private static final int TICKS_PER_DAY = 24000;

    private final java.util.Set<java.util.UUID> playersKnownInFirstTwoDays = new java.util.HashSet<>();

    public VerityEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createVerityAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0);
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(STATE, VerityState.FRIENDLY.getId());
        this.dataTracker.startTracking(TICKS_ALIVE, 0);
        this.dataTracker.startTracking(RULE_BROKEN, false);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new VerityStalkGoal(this));
        this.goalSelector.add(2, new VerityFollowGoal(this));
        this.goalSelector.add(3, new VerityWhisperGoal(this));
        this.goalSelector.add(4, new net.minecraft.entity.ai.goal.LookAroundGoal(this));
    }

    // ----- State helpers -----

    public VerityState getState() {
        return VerityState.byId(this.dataTracker.get(STATE));
    }

    private void setState(VerityState state) {
        this.dataTracker.set(STATE, state.getId());
    }

    public boolean isSuspicious() {
        return getState() == VerityState.SUSPICIOUS;
    }

    public boolean isTransformed() {
        return getState() == VerityState.TRANSFORMED;
    }

    public int getDaysUntilTransformation() {
        int ticksAlive = this.dataTracker.get(TICKS_ALIVE);
        int daysPassed = ticksAlive / TICKS_PER_DAY;
        return Math.max(0, TRANSFORMATION_DAY_COUNT - daysPassed);
    }

    private void markRuleBroken() {
        this.dataTracker.set(RULE_BROKEN, true);
    }

    // ----- Tick logic: the whole horror arc lives here -----

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) return;

        int ticks = this.dataTracker.get(TICKS_ALIVE) + 1;
        this.dataTracker.set(TICKS_ALIVE, ticks);

        checkForBrokenRules();

        VerityState current = getState();
        if (current == VerityState.FRIENDLY && ticks > TICKS_PER_DAY) {
            transitionTo(VerityState.SUSPICIOUS);
        }

        boolean countdownExpired = getDaysUntilTransformation() <= 0;
        boolean ruleBroken = this.dataTracker.get(RULE_BROKEN);
        if (current != VerityState.TRANSFORMED && (countdownExpired || ruleBroken)) {
            transformIntoHostileForm();
        }
    }

    /** "You shouldn't invite another friend after two days." */
    private void checkForBrokenRules() {
        if (this.dataTracker.get(RULE_BROKEN)) return;

        List<PlayerEntity> nearby = this.getWorld().getEntitiesByClass(
                PlayerEntity.class, this.getBoundingBox().expand(32.0), p -> true);

        int daysPassed = this.dataTracker.get(TICKS_ALIVE) / TICKS_PER_DAY;

        if (daysPassed < 2) {
            for (PlayerEntity player : nearby) {
                playersKnownInFirstTwoDays.add(player.getUuid());
            }
            return;
        }

        for (PlayerEntity player : nearby) {
            if (!playersKnownInFirstTwoDays.contains(player.getUuid())) {
                markRuleBroken();
                break;
            }
        }
    }

    private void transitionTo(VerityState state) {
        setState(state);
        if (state == VerityState.SUSPICIOUS && !this.getWorld().isClient) {
            this.getWorld().playSound(null, this.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_HIT,
                    SoundCategory.HOSTILE, 1.0f, 0.4f);
        }
    }

    private void transformIntoHostileForm() {
        setState(VerityState.TRANSFORMED);
        if (this.getWorld() instanceof ServerWorld serverWorld) {
            serverWorld.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN,
                    SoundCategory.HOSTILE, 1.0f, 1.4f);
            List<PlayerEntity> nearby = this.getWorld().getEntitiesByClass(
                    PlayerEntity.class, this.getBoundingBox().expand(48.0), p -> true);
            for (PlayerEntity player : nearby) {
                player.sendMessage(Text.translatable("veritymod.transform")
                        .formatted(Formatting.DARK_RED, Formatting.BOLD), false);
            }
            // Boost stats for the stalker phase.
            this.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.32);
            this.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(10.0);
        }
    }

    // ----- Chat interaction (right-click to talk) -----

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (this.isTransformed()) {
            // No more friendly chat once transformed - only dread.
            return super.interactMob(player, hand);
        }
        if (this.getWorld().isClient) {
            return ActionResult.SUCCESS;
        }
        if (player.isSneaking()) {
            return ActionResult.PASS;
        }

        player.sendMessage(Text.literal("Verity tilts its head, listening...")
                .formatted(Formatting.GRAY, Formatting.ITALIC), true);

        String context = "The player has known Verity for " +
                (this.dataTracker.get(TICKS_ALIVE) / TICKS_PER_DAY) + " day(s). Current mood: " + getState();

        // In a full build you'd pull the player's last typed chat line via a mixin/command;
        // here we prompt Verity generically when right-clicked without a specific message.
        VerityChatHandler.ask("The player just walked up to you and said hello.", context, reply ->
                this.getServer().execute(() -> player.sendMessage(
                        Text.literal("Verity: ").formatted(Formatting.YELLOW)
                                .append(Text.literal(reply).formatted(Formatting.WHITE)),
                        false)));

        return ActionResult.CONSUME;
    }

    /** Called from the /talktoverity command so players can type a real message to it. */
    public void respondTo(PlayerEntity player, String message) {
        if (this.isTransformed()) {
            player.sendMessage(Text.literal("Verity doesn't respond. It only watches.")
                    .formatted(Formatting.DARK_GRAY), false);
            return;
        }
        String context = "The player has known Verity for " +
                (this.dataTracker.get(TICKS_ALIVE) / TICKS_PER_DAY) + " day(s). Current mood: " + getState();

        VerityChatHandler.ask(message, context, reply ->
                this.getServer().execute(() -> player.sendMessage(
                        Text.literal("Verity: ").formatted(Formatting.YELLOW)
                                .append(Text.literal(reply).formatted(Formatting.WHITE)),
                        false)));
    }

    // ----- Persistence -----

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("VerityState", this.dataTracker.get(STATE));
        nbt.putInt("VerityTicksAlive", this.dataTracker.get(TICKS_ALIVE));
        nbt.putBoolean("VerityRuleBroken", this.dataTracker.get(RULE_BROKEN));

        net.minecraft.nbt.NbtList knownPlayers = new net.minecraft.nbt.NbtList();
        for (java.util.UUID uuid : playersKnownInFirstTwoDays) {
            knownPlayers.add(net.minecraft.nbt.NbtHelper.fromUuid(uuid));
        }
        nbt.put("VerityKnownPlayers", knownPlayers);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.dataTracker.set(STATE, nbt.getInt("VerityState"));
        this.dataTracker.set(TICKS_ALIVE, nbt.getInt("VerityTicksAlive"));
        this.dataTracker.set(RULE_BROKEN, nbt.getBoolean("VerityRuleBroken"));

        playersKnownInFirstTwoDays.clear();
        if (nbt.contains("VerityKnownPlayers")) {
            net.minecraft.nbt.NbtList knownPlayers = nbt.getList("VerityKnownPlayers", 11); // 11 = int array tag
            for (int i = 0; i < knownPlayers.size(); i++) {
                playersKnownInFirstTwoDays.add(net.minecraft.nbt.NbtHelper.toUuid(knownPlayers.get(i)));
            }
        }
    }

    @Override
    public boolean cannotDespawn() {
        return true;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }
}
