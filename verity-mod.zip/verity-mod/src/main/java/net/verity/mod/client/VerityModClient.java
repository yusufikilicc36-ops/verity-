package net.verity.mod.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;
import net.verity.mod.VerityMod;
import net.verity.mod.entity.ModEntities;

public class VerityModClient implements ClientModInitializer {

    public static final EntityModelLayer VERITY_MODEL_LAYER =
            new EntityModelLayer(new Identifier(VerityMod.MOD_ID, "verity"), "main");

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(VERITY_MODEL_LAYER, VerityEntityModel::getTexturedModelData);
        EntityRendererRegistry.register(ModEntities.VERITY, VerityEntityRenderer::new);
    }
}
