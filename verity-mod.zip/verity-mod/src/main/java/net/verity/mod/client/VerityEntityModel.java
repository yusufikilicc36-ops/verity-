package net.verity.mod.client;

import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.entity.Entity;
import net.verity.mod.entity.VerityEntity;

/**
 * A deliberately simple floating-blob model: a rounded body + two eye
 * cuboids. Friendly form is small; the renderer scales it up and darkens
 * the texture once the entity is TRANSFORMED (see VerityEntityRenderer).
 */
public class VerityEntityModel extends EntityModel<VerityEntity> {

    private final ModelPart body;
    private final ModelPart leftEye;
    private final ModelPart rightEye;

    public VerityEntityModel(ModelPart root) {
        this.body = root.getChild("body");
        this.leftEye = this.body.getChild("left_eye");
        this.rightEye = this.body.getChild("right_eye");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        ModelPartData body = root.addChild("body",
                ModelPartBuilder.create().uv(0, 0)
                        .cuboid(-4.0f, -8.0f, -4.0f, 8, 8, 8),
                ModelTransform.pivot(0.0f, 16.0f, 0.0f));

        body.addChild("left_eye",
                ModelPartBuilder.create().uv(0, 16)
                        .cuboid(-3.0f, -5.0f, -4.01f, 2, 2, 0),
                ModelTransform.NONE);

        body.addChild("right_eye",
                ModelPartBuilder.create().uv(6, 16)
                        .cuboid(1.0f, -5.0f, -4.01f, 2, 2, 0),
                ModelTransform.NONE);

        return TexturedModelData.of(modelData, 32, 32);
    }

    @Override
    public void setAngles(VerityEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        // Gentle bob + subtle head-turn toward the camera; more erratic once transformed.
        float bob = (float) Math.sin(animationProgress / 8.0f) * (entity.isTransformed() ? 0.02f : 0.06f);
        this.body.pitch = bob;
        this.body.yaw = headYaw * ((float) Math.PI / 180f) * (entity.isTransformed() ? 1.0f : 0.5f);
    }

    @Override
    public void render(net.minecraft.client.util.math.MatrixStack matrices, net.minecraft.client.render.VertexConsumer vertices, int light, int overlay, float red, float green, float blue, float alpha) {
        body.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
