package net.verity.mod.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.verity.mod.VerityMod;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Sends the player's message (plus a short rolling history) to whatever
 * OpenAI-compatible endpoint is configured, off the main server thread, and
 * hands the reply back to the given callback.
 */
public final class VerityChatHandler {

    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8))
            .build();

    private VerityChatHandler() {
    }

    public static void ask(String playerMessage, String extraContext, Consumer<String> onReply) {
        VerityAIConfig config = VerityAIConfig.get();

        if (config.apiKey == null || config.apiKey.isBlank() || config.apiKey.equals("PUT_YOUR_API_KEY_HERE")) {
            onReply.accept("...(Verity stares blankly. No API key is configured in config/veritymod.properties)");
            return;
        }

        JsonObject body = new JsonObject();
        body.addProperty("model", config.model);

        JsonArray messages = new JsonArray();
        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content", config.systemPrompt + (extraContext.isEmpty() ? "" : ("\nContext: " + extraContext)));
        messages.add(system);

        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", playerMessage);
        messages.add(user);

        body.add("messages", messages);
        body.addProperty("max_tokens", 150);
        body.addProperty("temperature", 0.9);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(config.apiUrl))
                .timeout(Duration.ofSeconds(15))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + config.apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() != 200) {
                    return "...(Verity's connection flickers. HTTP " + response.statusCode() + ")";
                }
                JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                return json.getAsJsonArray("choices")
                        .get(0).getAsJsonObject()
                        .getAsJsonObject("message")
                        .get("content").getAsString()
                        .trim();
            } catch (Exception e) {
                VerityMod.LOGGER.error("Verity AI request failed", e);
                return "...(Verity doesn't answer.)";
            }
        }).thenAccept(onReply);
    }
}
