package net.verity.mod.entity;

/**
 * The behavioral phase Verity is currently in.
 * <p>
 * FRIENDLY    - just spawned. Follows the player, answers chat questions, plays music.
 * SUSPICIOUS  - trust/day counter has advanced. Whispers get darker, rules appear.
 * TRANSFORMED - the countdown has hit zero (or a rule was broken). Hostile stalker form.
 */
public enum VerityState {
    FRIENDLY(0),
    SUSPICIOUS(1),
    TRANSFORMED(2);

    private final int id;

    VerityState(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public static VerityState byId(int id) {
        for (VerityState state : values()) {
            if (state.id == id) return state;
        }
        return FRIENDLY;
    }
}
