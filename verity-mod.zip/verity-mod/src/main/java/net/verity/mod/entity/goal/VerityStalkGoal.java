package net.verity.mod.entity.goal;

import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.verity.mod.entity.VerityEntity;

import java.util.EnumSet;
import java.util.List;

/**
 * Only active while the entity is TRANSFORMED. Instead of pathing normally,
 * Verity periodically vanishes and reappears closer to the player -
 * but only while the player isn't looking directly at it (classic
 * Slenderman / SCP-173 "watched" mechanic).
 */
public class VerityStalkGoal extends Goal {

    private final VerityEntity verity;
    private int teleportCooldown = 0;

    public VerityStalkGoal(VerityEntity verity) {
        this.verity = verity;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        return verity.isTransformed();
    }

    @Override
    public boolean shouldContinue() {
        return verity.isTransformed();
    }

    @Override
    public void tick() {
        if (teleportCooldown > 0) {
            teleportCooldown--;
            return;
        }

        PlayerEntity target = verity.getWorld().getClosestPlayer(verity, 48.0);
        if (target == null) return;

        boolean watched = isBeingWatchedBy(target);

        if (watched) {
            // Freeze completely while being observed - unsettling stillness.
            verity.getNavigation().stop();
            verity.setVelocity(0, verity.getVelocity().y, 0);
            return;
        }

        // Not being watched: close the distance, abruptly.
        double distance = verity.squaredDistanceTo(target);
        if (distance > 9.0) {
            teleportNear(target);
            teleportCooldown = 20 + verity.getRandom().nextInt(40); // 1-3s between teleports
        }
    }

    private boolean isBeingWatchedBy(PlayerEntity player) {
        Vec3d toEntity = verity.getPos().subtract(player.getEyePos()).normalize();
        Vec3d look = player.getRotationVector().normalize();
        double dot = toEntity.dotProduct(look);
        // dot close to 1 means the player is looking roughly straight at it
        boolean withinCone = dot > 0.75;
        boolean hasLineOfSight = player.canSee(verity);
        return withinCone && hasLineOfSight;
    }

    private void teleportNear(PlayerEntity target) {
        if (!(verity.getWorld() instanceof ServerWorld serverWorld)) return;

        BlockPos playerPos = target.getBlockPos();
        for (int attempt = 0; attempt < 12; attempt++) {
            int dx = -4 + verity.getRandom().nextInt(9);
            int dz = -4 + verity.getRandom().nextInt(9);
            BlockPos candidate = playerPos.add(dx, 0, dz);
            BlockPos ground = findGround(serverWorld, candidate);
            if (ground != null) {
                verity.teleport(ground.getX() + 0.5, ground.getY(), ground.getZ() + 0.5, false);
                serverWorld.playSound(null, ground, net.minecraft.sound.SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                        net.minecraft.sound.SoundCategory.HOSTILE, 0.6f, 0.5f);
                return;
            }
        }
    }

    private BlockPos findGround(World world, BlockPos start) {
        BlockPos.Mutable pos = start.mutableCopy();
        for (int y = 0; y < 6; y++) {
            if (!world.getBlockState(pos).isAir() && world.getBlockState(pos.up()).isAir()
                    && world.getBlockState(pos.up(2)).isAir()) {
                return pos.up().toImmutable();
            }
            pos.move(0, -1, 0);
        }
        return null;
    }
}
