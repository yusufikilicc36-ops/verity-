package net.verity.mod.entity.goal;

import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.verity.mod.entity.VerityEntity;
import net.verity.mod.entity.VerityState;

import java.util.EnumSet;

public class VerityFollowGoal extends Goal {

    private final VerityEntity verity;
    private PlayerEntity target;
    private int recalcCooldown;

    public VerityFollowGoal(VerityEntity verity) {
        this.verity = verity;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        if (verity.getState() == VerityState.TRANSFORMED) return false;
        target = verity.getWorld().getClosestPlayer(verity, 16.0);
        return target != null;
    }

    @Override
    public boolean shouldContinue() {
        return target != null && target.isAlive()
                && verity.getState() != VerityState.TRANSFORMED
                && verity.squaredDistanceTo(target) < 400.0;
    }

    @Override
    public void start() {
        recalcCooldown = 0;
    }

    @Override
    public void stop() {
        target = null;
        verity.getNavigation().stop();
    }

    @Override
    public void tick() {
        verity.getLookControl().lookAt(target, 30.0f, 30.0f);
        if (--recalcCooldown > 0) return;
        recalcCooldown = 10;

        double distSq = verity.squaredDistanceTo(target);
        if (distSq > 6.0) {
            verity.getNavigation().startMovingTo(target, verity.isSuspicious() ? 0.85 : 1.0);
        } else {
            verity.getNavigation().stop();
        }
    }
}
