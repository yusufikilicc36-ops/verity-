# Verity (Fabric 1.20.1 remake)

A from-scratch Fabric mod that recreates the "Verity" horror concept: a small
yellow companion that starts friendly, whispers increasingly unsettling lines
on a countdown, breaks its own rules if you invite another player late, and
eventually transforms into a hostile stalker that teleports closer whenever
you're not looking at it.

## What's actually implemented

- **Custom entity** (`VerityEntity`) with 3 states: `FRIENDLY` → `SUSPICIOUS` → `TRANSFORMED`.
- **Day counter**: after 1 Minecraft day it turns SUSPICIOUS; after 3 days (or if a rule
  is broken) it transforms.
- **Rule-breaking**: if a player who wasn't around during the first 2 days shows up
  after that point, Verity transforms early.
- **Whispers**: periodic in-chat messages to nearby players, escalating as the
  countdown gets closer (see `en_us.json` for all lines).
- **Follow behavior**: while friendly/suspicious, it trails the nearest player like a companion.
- **Stalker behavior**: once transformed, it freezes solid whenever a player looks
  directly at it, and teleports closer the instant they look away (Slenderman/SCP-173 style).
- **Real AI chat**: `/talktoverity <message>` sends your message to any
  OpenAI-compatible chat completions API (Groq, OpenAI, OpenRouter, local
  llama.cpp server, etc.) and prints Verity's reply in chat. Right-clicking it
  also triggers a generic greeting exchange.
- **Spawn egg** in the creative inventory (Spawn Eggs tab) to test it.
- Placeholder textures (plain yellow / dark blob) so it renders instead of
  crashing — **swap these for real art**, see below.

## Setting up the AI chat

On first launch, the mod writes `config/veritymod.properties` in your server/client
run directory:

```properties
apiUrl=https://api.groq.com/openai/v1/chat/completions
apiKey=PUT_YOUR_API_KEY_HERE
model=llama-3.1-8b-instant
systemPrompt=You are Verity...
```

Put a real API key in there (Groq has a free tier). Without a key, Verity just
replies with a placeholder "no API key configured" line instead of crashing.

## Things you'll want to improve

1. **Textures/model** — the current model is a plain floating cube with two
   flat eye cuboids, textured with solid-color placeholder PNGs
   (`textures/entity/verity_friendly.png` / `verity_transformed.png`). Replace
   these with real art (e.g. block out in Blockbench) for the actual look
   from the videos.
2. **Sound design** — currently reuses vanilla sounds (amethyst hit, wither
   spawn, enderman teleport) as stand-ins. Custom ambient whisper audio would
   sell the horror far better than chat text alone.
3. **Chat message capture** — `interactMob` (right-click) can't read what a
   player actually typed in normal chat; that's why `/talktoverity` exists as
   the "real" way to talk to it. A mixin into `ServerPlayNetworkHandler`'s
   chat handling could route ordinary chat messages near Verity into the AI
   automatically, matching the original's "just talk near it" feel — left out
   here to keep things simple and mixin-free.
4. **Difficulty/attack behavior** — transformed Verity currently doesn't have
   an explicit melee-attack goal wired in; add `MeleeAttackGoal` (or a custom
   one) to `initGoals()` if you want it to actually damage the player instead
   of just being an ominous stalking presence.

## Building

This project targets Fabric Loom + Yarn mappings for 1.20.1. From the project
root (needs internet access to pull Minecraft/Fabric/Yarn artifacts, which
this sandbox does not have):

```bash
./gradlew build
```

The compiled mod jar will be in `build/libs/`.
